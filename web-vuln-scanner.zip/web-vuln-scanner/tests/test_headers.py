import unittest
from unittest.mock import MagicMock, patch
from scanner.modules.headers import check_headers, HeaderFinding


class TestHeadersModule(unittest.TestCase):

    def _mock_response(self, headers: dict) -> MagicMock:
        response = MagicMock()
        response.headers = headers
        response.status_code = 200
        return response

    @patch("scanner.modules.headers.safe_get")
    @patch("scanner.modules.headers.build_session")
    def test_detects_missing_hsts(self, mock_session, mock_get):
        mock_get.return_value = self._mock_response({
            "Content-Type": "text/html",
            "Content-Security-Policy": "default-src 'self'",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Permissions-Policy": "geolocation=()",
            "X-XSS-Protection": "1; mode=block",
        })
        findings = check_headers("https://example.com")
        missing = [f for f in findings if f.header == "Strict-Transport-Security"]
        self.assertEqual(len(missing), 1)
        self.assertEqual(missing[0].severity, "HIGH")

    @patch("scanner.modules.headers.safe_get")
    @patch("scanner.modules.headers.build_session")
    def test_detects_server_header_exposure(self, mock_session, mock_get):
        mock_get.return_value = self._mock_response({
            "Content-Type": "text/html",
            "Server": "Apache/2.4.51 (Ubuntu)",
            "Strict-Transport-Security": "max-age=31536000",
            "Content-Security-Policy": "default-src 'self'",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Permissions-Policy": "geolocation=()",
            "X-XSS-Protection": "1; mode=block",
        })
        findings = check_headers("https://example.com")
        server_finding = [f for f in findings if f.header == "Server"]
        self.assertEqual(len(server_finding), 1)
        self.assertIn("Apache", server_finding[0].value)

    @patch("scanner.modules.headers.safe_get")
    @patch("scanner.modules.headers.build_session")
    def test_no_findings_when_all_headers_present(self, mock_session, mock_get):
        mock_get.return_value = self._mock_response({
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Content-Security-Policy": "default-src 'self'",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": "geolocation=()",
            "X-XSS-Protection": "1; mode=block",
        })
        findings = check_headers("https://example.com")
        self.assertEqual(len(findings), 0)

    @patch("scanner.modules.headers.safe_get")
    @patch("scanner.modules.headers.build_session")
    def test_returns_empty_on_connection_failure(self, mock_session, mock_get):
        mock_get.return_value = None
        findings = check_headers("https://unreachable.example.com")
        self.assertEqual(findings, [])


if __name__ == "__main__":
    unittest.main()
