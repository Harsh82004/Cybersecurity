import unittest
from unittest.mock import MagicMock, patch
from scanner.core.crawler import CrawlResult, Form, FormField
from scanner.modules.sqli import check_sqli, _is_sqli_response


class TestSQLiModule(unittest.TestCase):

    def test_detects_mysql_error_pattern(self):
        is_vuln, evidence = _is_sqli_response(
            "You have an error in your SQL syntax; check the manual"
        )
        self.assertTrue(is_vuln)
        self.assertIn("sql syntax", evidence)

    def test_detects_oracle_error_pattern(self):
        is_vuln, evidence = _is_sqli_response(
            "ORA-00933: SQL command not properly ended"
        )
        self.assertTrue(is_vuln)

    def test_no_false_positive_on_clean_response(self):
        is_vuln, _ = _is_sqli_response("<html><body>Welcome to our store!</body></html>")
        self.assertFalse(is_vuln)

    def test_detects_mssql_error(self):
        is_vuln, evidence = _is_sqli_response(
            "Microsoft SQL Server error: Incorrect syntax near \'1\'"
        )
        self.assertTrue(is_vuln)

    @patch("scanner.modules.sqli.safe_get")
    @patch("scanner.modules.sqli.build_session")
    def test_sqli_found_in_url_param(self, mock_session_cls, mock_get):
        vuln_response = MagicMock()
        vuln_response.text = "You have an error in your SQL syntax near '''"
        mock_get.return_value = vuln_response

        crawl_result = CrawlResult(
            base_url="https://example.com",
            urls={"https://example.com/search?q=test"},
            params={"https://example.com/search?q=test": ["q"]},
        )
        findings = check_sqli(crawl_result)
        self.assertGreater(len(findings), 0)
        self.assertEqual(findings[0].parameter, "q")
        self.assertEqual(findings[0].severity, "HIGH")

    @patch("scanner.modules.sqli.safe_post")
    @patch("scanner.modules.sqli.safe_get")
    @patch("scanner.modules.sqli.build_session")
    def test_sqli_found_in_form(self, mock_session_cls, mock_get, mock_post):
        clean = MagicMock()
        clean.text = "Normal response"
        vuln = MagicMock()
        vuln.text = "Warning: mysql_fetch_array()"
        # username tries all payloads; give enough cleans then a vuln hit
        mock_post.side_effect = [clean] * 3 + [vuln] + [clean] * 20
        mock_get.return_value = clean

        form = Form(
            action="https://example.com/login",
            method="post",
            fields=[
                FormField(name="username", field_type="text"),
                FormField(name="password", field_type="password"),
            ],
        )
        crawl_result = CrawlResult(base_url="https://example.com", forms=[form])
        findings = check_sqli(crawl_result)
        self.assertGreater(len(findings), 0)

    def test_no_sqli_findings_on_clean_target(self):
        crawl_result = CrawlResult(base_url="https://example.com")
        with patch("scanner.modules.sqli.build_session"), \
             patch("scanner.modules.sqli.safe_get") as mock_get:
            clean = MagicMock()
            clean.text = "Everything is fine"
            mock_get.return_value = clean
            findings = check_sqli(crawl_result)
        self.assertEqual(findings, [])


if __name__ == "__main__":
    unittest.main()
