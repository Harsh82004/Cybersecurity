import unittest
from unittest.mock import MagicMock, patch
from scanner.core.crawler import CrawlResult, Form, FormField
from scanner.modules.xss import check_xss, _is_reflected


class TestXSSModule(unittest.TestCase):

    def test_detects_reflected_script_tag(self):
        self.assertTrue(_is_reflected('<html><script>alert("XSS")</script></html>', '<script>alert("XSS")</script>'))

    def test_no_reflection_on_clean_response(self):
        self.assertFalse(_is_reflected("<html><body>Hello World</body></html>", '<script>alert(1)</script>'))

    def test_case_insensitive_reflection_detection(self):
        self.assertTrue(_is_reflected("<body>INPUT: <IMG SRC=X ONERROR=ALERT(1)></body>", "<img src=x onerror=alert(1)>"))

    @patch("scanner.modules.xss.safe_get")
    @patch("scanner.modules.xss.build_session")
    def test_xss_found_in_url_param(self, mock_session_cls, mock_get):
        def side_effect(session, url, **kwargs):
            response = MagicMock()
            if "xss_probe_marker_7x9z" in url or "%3Cxss_probe" in url:
                response.text = "<html>Search: xss_probe_marker_7x9z</html>"
            elif "onerror" in url.lower() or "script" in url.lower() or "svg" in url.lower():
                response.text = "<html>Search: <img src=x onerror=alert(1)></html>"
            else:
                response.text = "<html>Search: safe</html>"
            return response

        mock_get.side_effect = side_effect

        crawl_result = CrawlResult(
            base_url="https://example.com",
            urls={"https://example.com/search?q=hello"},
            params={"https://example.com/search?q=hello": ["q"]},
        )
        findings = check_xss(crawl_result)
        self.assertGreater(len(findings), 0)
        self.assertTrue(findings[0].reflected)

    @patch("scanner.modules.xss.safe_get")
    @patch("scanner.modules.xss.build_session")
    def test_no_xss_when_value_not_reflected(self, mock_session_cls, mock_get):
        def side_effect(session, url, **kwargs):
            response = MagicMock()
            response.text = "<html><body>Fixed content, nothing reflected</body></html>"
            return response

        mock_get.side_effect = side_effect

        crawl_result = CrawlResult(
            base_url="https://example.com",
            params={"https://example.com/search?q=hello": ["q"]},
        )
        findings = check_xss(crawl_result)
        self.assertEqual(findings, [])

    @patch("scanner.modules.xss.safe_post")
    @patch("scanner.modules.xss.safe_get")
    @patch("scanner.modules.xss.build_session")
    def test_xss_found_in_form(self, mock_session_cls, mock_get, mock_post):
        def get_side_effect(session, url, **kwargs):
            response = MagicMock()
            params = kwargs.get("params", {})
            if "xss_probe_marker_7x9z" in str(params):
                response.text = "<html>Input: xss_probe_marker_7x9z</html>"
            elif "<svg" in str(params):
                response.text = "<html>Input: <svg onload=alert(1)></html>"
            else:
                response.text = "<html>Form</html>"
            return response

        mock_get.side_effect = get_side_effect

        form = Form(
            action="https://example.com/comment",
            method="get",
            fields=[FormField(name="comment", field_type="text", value="hello")],
        )
        crawl_result = CrawlResult(base_url="https://example.com", forms=[form])
        findings = check_xss(crawl_result)
        self.assertGreater(len(findings), 0)


if __name__ == "__main__":
    unittest.main()
