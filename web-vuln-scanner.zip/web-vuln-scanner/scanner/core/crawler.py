from urllib.parse import urljoin, urlparse, urlencode, parse_qs
from bs4 import BeautifulSoup
from dataclasses import dataclass, field
from typing import Optional
import re

from scanner.utils.http_client import build_session, safe_get
from scanner.utils.logger import get_logger

logger = get_logger()


@dataclass
class FormField:
    name: str
    field_type: str
    value: str = ""


@dataclass
class Form:
    action: str
    method: str
    fields: list[FormField] = field(default_factory=list)


@dataclass
class CrawlResult:
    base_url: str
    urls: set[str] = field(default_factory=set)
    forms: list[Form] = field(default_factory=list)
    params: dict[str, list[str]] = field(default_factory=dict)  # url -> query params


class Crawler:
    def __init__(self, base_url: str, max_depth: int = 2, max_urls: int = 50, timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.base_domain = urlparse(base_url).netloc
        self.max_depth = max_depth
        self.max_urls = max_urls
        self.session = build_session(timeout=timeout)
        self.visited: set[str] = set()
        self.result = CrawlResult(base_url=base_url)

    def is_same_domain(self, url: str) -> bool:
        return urlparse(url).netloc == self.base_domain

    def normalize_url(self, url: str) -> Optional[str]:
        url = url.strip()
        if not url or url.startswith(("#", "javascript:", "mailto:", "tel:")):
            return None
        full = urljoin(self.base_url, url)
        parsed = urlparse(full)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

    def extract_forms(self, html: str, page_url: str) -> list[Form]:
        forms = []
        soup = BeautifulSoup(html, "html.parser")
        for form_tag in soup.find_all("form"):
            action = urljoin(page_url, form_tag.get("action", page_url))
            method = form_tag.get("method", "get").lower()
            fields = []
            for inp in form_tag.find_all(["input", "textarea", "select"]):
                name = inp.get("name")
                if not name:
                    continue
                field_type = inp.get("type", "text")
                value = inp.get("value", "test")
                fields.append(FormField(name=name, field_type=field_type, value=value))
            forms.append(Form(action=action, method=method, fields=fields))
        return forms

    def extract_links(self, html: str, page_url: str) -> set[str]:
        soup = BeautifulSoup(html, "html.parser")
        links = set()
        for tag in soup.find_all("a", href=True):
            normalized = self.normalize_url(tag["href"])
            if normalized and self.is_same_domain(normalized):
                links.add(normalized)
        return links

    def extract_params(self, url: str) -> list[str]:
        parsed = urlparse(url)
        return list(parse_qs(parsed.query).keys())

    def crawl(self) -> CrawlResult:
        logger.info(f"Starting crawl on {self.base_url} (depth={self.max_depth}, max_urls={self.max_urls})")
        self._crawl_recursive(self.base_url, depth=0)
        logger.info(f"Crawl complete — {len(self.result.urls)} URLs, {len(self.result.forms)} forms found")
        return self.result

    def _crawl_recursive(self, url: str, depth: int):
        if depth > self.max_depth or url in self.visited or len(self.visited) >= self.max_urls:
            return

        self.visited.add(url)
        response = safe_get(self.session, url)
        if not response or "text/html" not in response.headers.get("Content-Type", ""):
            return

        self.result.urls.add(url)

        # Track URLs with query params for injection testing
        params = self.extract_params(url)
        if params:
            self.result.params[url] = params

        forms = self.extract_forms(response.text, url)
        self.result.forms.extend(forms)

        for link in self.extract_links(response.text, url):
            if link not in self.visited:
                self._crawl_recursive(link, depth + 1)
