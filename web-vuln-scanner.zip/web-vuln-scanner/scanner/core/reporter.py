import json
import os
from datetime import datetime
from dataclasses import asdict, is_dataclass
from typing import Any

from scanner.utils.logger import get_logger

logger = get_logger()

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
SEVERITY_COLORS = {
    "CRITICAL": "#dc2626",
    "HIGH": "#ea580c",
    "MEDIUM": "#ca8a04",
    "LOW": "#2563eb",
    "INFO": "#16a34a",
}


def _to_dict(obj: Any) -> Any:
    if is_dataclass(obj):
        return asdict(obj)
    elif isinstance(obj, (set, list, tuple)):
        return [_to_dict(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    return obj


def generate_json_report(scan_data: dict, output_path: str) -> str:
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(_to_dict(scan_data), f, indent=2, default=str)
    logger.info(f"JSON report saved to {output_path}")
    return output_path


def generate_html_report(scan_data: dict, output_path: str) -> str:
    target = scan_data.get("target", "")
    scan_time = scan_data.get("scan_time", "")
    all_findings = scan_data.get("all_findings_flat", [])

    total = len(all_findings)
    counts = {s: 0 for s in SEVERITY_ORDER}
    for f in all_findings:
        sev = f.get("severity", "INFO").upper()
        counts[sev] = counts.get(sev, 0) + 1

    finding_rows = ""
    for f in sorted(all_findings, key=lambda x: SEVERITY_ORDER.get(x.get("severity", "INFO").upper(), 4)):
        sev = f.get("severity", "INFO").upper()
        color = SEVERITY_COLORS.get(sev, "#6b7280")
        finding_rows += f"""
        <tr>
          <td><span class="badge" style="background:{color}">{sev}</span></td>
          <td>{f.get('module', '')}</td>
          <td>{f.get('url', f.get('header', ''))}</td>
          <td>{f.get('description', f.get('detail', ''))}</td>
          <td style="font-family:monospace;font-size:0.8em">{f.get('payload', f.get('recommendation', ''))}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>WebVulnScan Report — {target}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; }}
    .header {{ background: linear-gradient(135deg, #1e293b, #0f172a); padding: 40px; border-bottom: 1px solid #334155; }}
    .header h1 {{ font-size: 2em; color: #38bdf8; }}
    .header p {{ color: #94a3b8; margin-top: 8px; }}
    .meta {{ display: flex; gap: 24px; margin-top: 20px; flex-wrap: wrap; }}
    .meta-item {{ background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 12px 20px; }}
    .meta-item label {{ display: block; font-size: 0.75em; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; }}
    .meta-item span {{ font-size: 1.1em; font-weight: 600; }}
    .summary {{ display: flex; gap: 16px; padding: 32px 40px; flex-wrap: wrap; }}
    .card {{ flex: 1; min-width: 140px; background: #1e293b; border-radius: 12px; padding: 20px; text-align: center; border: 1px solid #334155; }}
    .card .count {{ font-size: 2.5em; font-weight: 700; }}
    .card .label {{ font-size: 0.85em; color: #94a3b8; margin-top: 4px; }}
    .section {{ padding: 0 40px 40px; }}
    .section h2 {{ font-size: 1.25em; color: #94a3b8; margin-bottom: 16px; border-bottom: 1px solid #334155; padding-bottom: 8px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.9em; }}
    th {{ background: #1e293b; color: #94a3b8; text-align: left; padding: 12px 16px; font-weight: 600; font-size: 0.8em; text-transform: uppercase; }}
    td {{ padding: 12px 16px; border-bottom: 1px solid #1e293b; vertical-align: top; }}
    tr:hover td {{ background: #1e293b; }}
    .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.75em; font-weight: 700; color: white; }}
    .footer {{ padding: 24px 40px; color: #475569; font-size: 0.8em; border-top: 1px solid #1e293b; }}
  </style>
</head>
<body>
  <div class="header">
    <h1>🔍 WebVulnScan Report</h1>
    <p>Automated web application vulnerability assessment</p>
    <div class="meta">
      <div class="meta-item"><label>Target</label><span>{target}</span></div>
      <div class="meta-item"><label>Scan Time</label><span>{scan_time}</span></div>
      <div class="meta-item"><label>Total Findings</label><span>{total}</span></div>
    </div>
  </div>

  <div class="summary">
    {"".join(f'<div class="card"><div class="count" style="color:{SEVERITY_COLORS[s]}">{counts[s]}</div><div class="label">{s}</div></div>' for s in SEVERITY_ORDER)}
  </div>

  <div class="section">
    <h2>All Findings</h2>
    {'<p style="color:#64748b">No findings detected.</p>' if not all_findings else f'''
    <table>
      <thead><tr><th>Severity</th><th>Module</th><th>URL / Header</th><th>Description</th><th>Detail / Payload</th></tr></thead>
      <tbody>{finding_rows}</tbody>
    </table>'''}
  </div>

  <div class="footer">
    Generated by WebVulnScanner v1.0.0 — For authorized security testing only.
  </div>
</body>
</html>"""

    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    with open(output_path, "w") as f:
        f.write(html)
    logger.info(f"HTML report saved to {output_path}")
    return output_path
