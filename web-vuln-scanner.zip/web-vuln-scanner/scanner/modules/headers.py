from dataclasses import dataclass
from scanner.utils.http_client import build_session, safe_get
from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

SECURITY_HEADERS = {
    "Strict-Transport-Security": {
        "severity": "HIGH",
        "description": "HSTS not set — forces HTTPS and prevents protocol downgrade attacks",
        "recommendation": "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload",
    },
    "Content-Security-Policy": {
        "severity": "HIGH",
        "description": "CSP not set — no control over resource loading, XSS risk increases",
        "recommendation": "Define a strict Content-Security-Policy to allowlist trusted sources",
    },
    "X-Frame-Options": {
        "severity": "MEDIUM",
        "description": "X-Frame-Options not set — page may be embeddable, enabling Clickjacking",
        "recommendation": "Add: X-Frame-Options: DENY or SAMEORIGIN",
    },
    "X-Content-Type-Options": {
        "severity": "MEDIUM",
        "description": "X-Content-Type-Options not set — browser may MIME-sniff responses",
        "recommendation": "Add: X-Content-Type-Options: nosniff",
    },
    "Referrer-Policy": {
        "severity": "LOW",
        "description": "Referrer-Policy not set — full URL may be leaked in referrer headers",
        "recommendation": "Add: Referrer-Policy: strict-origin-when-cross-origin",
    },
    "Permissions-Policy": {
        "severity": "LOW",
        "description": "Permissions-Policy not set — browser features (camera, mic) not restricted",
        "recommendation": "Add: Permissions-Policy: geolocation=(), camera=(), microphone=()",
    },
    "X-XSS-Protection": {
        "severity": "INFO",
        "description": "X-XSS-Protection header missing (legacy but still checked by some scanners)",
        "recommendation": "Add: X-XSS-Protection: 1; mode=block",
    },
}

INSECURE_HEADER_VALUES = {
    "Server": {
        "pattern": r".+",
        "severity": "LOW",
        "description": "Server header reveals software version — aids fingerprinting",
        "recommendation": "Suppress or genericize the Server header",
    },
    "X-Powered-By": {
        "pattern": r".+",
        "severity": "LOW",
        "description": "X-Powered-By reveals framework/language — aids targeted attacks",
        "recommendation": "Remove X-Powered-By header entirely",
    },
}


@dataclass
class HeaderFinding:
    header: str
    severity: str
    description: str
    recommendation: str
    present: bool
    value: str = ""


def check_headers(url: str) -> list[HeaderFinding]:
    logger.info(f"[Headers] Checking security headers on {url}")
    session = build_session()
    response = safe_get(session, url)

    if not response:
        logger.warning(f"[Headers] Could not reach {url}")
        return []

    findings = []
    response_headers = {k.lower(): v for k, v in response.headers.items()}

    # Check missing security headers
    for header, meta in SECURITY_HEADERS.items():
        if header.lower() not in response_headers:
            finding = HeaderFinding(
                header=header,
                severity=meta["severity"],
                description=meta["description"],
                recommendation=meta["recommendation"],
                present=False,
            )
            findings.append(finding)
            print_finding(meta["severity"], "Headers", f"Missing: {header} — {meta['description']}")

    # Check for information-leaking headers
    for header, meta in INSECURE_HEADER_VALUES.items():
        value = response_headers.get(header.lower(), "")
        if value:
            finding = HeaderFinding(
                header=header,
                severity=meta["severity"],
                description=meta["description"],
                recommendation=meta["recommendation"],
                present=True,
                value=value,
            )
            findings.append(finding)
            print_finding(meta["severity"], "Headers", f"Exposed: {header}: {value}")

    if not findings:
        print_finding("INFO", "Headers", "All major security headers are present ✓")

    return findings
