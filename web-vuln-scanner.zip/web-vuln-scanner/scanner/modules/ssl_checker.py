import ssl
import socket
from datetime import datetime, timezone
from dataclasses import dataclass, field
from urllib.parse import urlparse

from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

WEAK_CIPHERS = {
    "RC4", "DES", "3DES", "NULL", "EXPORT", "anon", "MD5", "RC2",
}

DEPRECATED_PROTOCOLS = {
    "SSLv2", "SSLv3", "TLSv1", "TLSv1.1",
}


@dataclass
class SSLFinding:
    severity: str
    description: str
    detail: str = ""


@dataclass
class SSLResult:
    url: str
    is_https: bool
    valid_cert: bool = False
    cert_expiry: str = ""
    days_until_expiry: int = 0
    protocol_version: str = ""
    cipher_suite: str = ""
    subject: str = ""
    issuer: str = ""
    findings: list[SSLFinding] = field(default_factory=list)


def check_ssl(target_url: str) -> SSLResult:
    logger.info(f"[SSL] Checking SSL/TLS configuration for {target_url}")
    parsed = urlparse(target_url)
    result = SSLResult(url=target_url, is_https=parsed.scheme == "https")

    if not result.is_https:
        finding = SSLFinding(
            severity="HIGH",
            description="Target is not using HTTPS — all traffic is transmitted in plaintext",
            detail="Switch to HTTPS and set up HTTP→HTTPS redirect",
        )
        result.findings.append(finding)
        print_finding("HIGH", "SSL", "Site is not using HTTPS")
        return result

    host = parsed.hostname
    port = parsed.port or 443

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                result.valid_cert = True
                result.protocol_version = ssock.version()
                result.cipher_suite = ssock.cipher()[0]

                # Parse subject / issuer
                subject = dict(x[0] for x in cert.get("subject", []))
                issuer = dict(x[0] for x in cert.get("issuer", []))
                result.subject = subject.get("commonName", "Unknown")
                result.issuer = issuer.get("organizationName", "Unknown")

                # Check expiry
                expiry_str = cert.get("notAfter", "")
                if expiry_str:
                    expiry = datetime.strptime(expiry_str, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    now = datetime.now(timezone.utc)
                    days_left = (expiry - now).days
                    result.cert_expiry = expiry.strftime("%Y-%m-%d")
                    result.days_until_expiry = days_left

                    if days_left < 0:
                        result.findings.append(SSLFinding("CRITICAL", "SSL certificate has EXPIRED", f"Expired on {result.cert_expiry}"))
                        print_finding("CRITICAL", "SSL", f"Certificate EXPIRED on {result.cert_expiry}")
                    elif days_left < 14:
                        result.findings.append(SSLFinding("HIGH", f"Certificate expires in {days_left} days", result.cert_expiry))
                        print_finding("HIGH", "SSL", f"Certificate expires in {days_left} days ({result.cert_expiry})")
                    elif days_left < 30:
                        result.findings.append(SSLFinding("MEDIUM", f"Certificate expires in {days_left} days", result.cert_expiry))
                        print_finding("MEDIUM", "SSL", f"Certificate expires in {days_left} days ({result.cert_expiry})")
                    else:
                        print_finding("INFO", "SSL", f"Certificate valid — expires in {days_left} days ({result.cert_expiry})")

                # Check for deprecated protocol
                if result.protocol_version in DEPRECATED_PROTOCOLS:
                    result.findings.append(SSLFinding("HIGH", f"Deprecated protocol in use: {result.protocol_version}", "Upgrade to TLS 1.2 or 1.3"))
                    print_finding("HIGH", "SSL", f"Deprecated protocol: {result.protocol_version}")
                else:
                    print_finding("INFO", "SSL", f"Protocol: {result.protocol_version}")

                # Check for weak ciphers
                cipher_upper = result.cipher_suite.upper()
                for weak in WEAK_CIPHERS:
                    if weak in cipher_upper:
                        result.findings.append(SSLFinding("HIGH", f"Weak cipher in use: {result.cipher_suite}", "Disable weak/legacy ciphers"))
                        print_finding("HIGH", "SSL", f"Weak cipher suite: {result.cipher_suite}")
                        break
                else:
                    print_finding("INFO", "SSL", f"Cipher: {result.cipher_suite}")

    except ssl.SSLCertVerificationError as e:
        result.valid_cert = False
        result.findings.append(SSLFinding("HIGH", "SSL certificate verification failed", str(e)))
        print_finding("HIGH", "SSL", f"Certificate verification failed: {e}")
    except ssl.SSLError as e:
        result.findings.append(SSLFinding("HIGH", f"SSL error: {e}", ""))
        print_finding("HIGH", "SSL", f"SSL error: {e}")
    except Exception as e:
        logger.warning(f"[SSL] Could not connect to {host}:{port} — {e}")

    return result
