from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from scanner.core.crawler import CrawlResult
from scanner.utils.http_client import build_session, safe_get
from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

REDIRECT_PAYLOADS = [
    "https://evil.com",
    "//evil.com",
    "https://evil.com%2F@legitimate.com",
    "/\\evil.com",
    "https:evil.com",
    "///evil.com",
    "http://evil%2ecom",
]

REDIRECT_PARAM_NAMES = {
    "redirect", "redirect_to", "redirect_url", "next", "url", "return",
    "return_url", "returnurl", "continue", "goto", "destination", "dest",
    "target", "redir", "location", "callback",
}


@dataclass
class RedirectFinding:
    url: str
    parameter: str
    payload: str
    destination: str
    severity: str = "MEDIUM"


def _is_open_redirect(response, payload: str) -> bool:
    if not response:
        return False
    # Check final URL after redirects
    final_url = response.url
    if "evil.com" in final_url:
        return True
    # Check if redirect location header points to our payload
    for r in response.history:
        location = r.headers.get("Location", "")
        if "evil.com" in location or payload in location:
            return True
    return False


def check_open_redirect(crawl_result: CrawlResult) -> list[RedirectFinding]:
    logger.info("[OpenRedirect] Checking for Open Redirect vulnerabilities")
    session = build_session()
    findings = []

    for url, params in crawl_result.params.items():
        parsed = urlparse(url)
        base_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        for param in params:
            if param.lower() not in REDIRECT_PARAM_NAMES:
                continue  # Only test redirect-like params

            for payload in REDIRECT_PAYLOADS:
                injected = {**base_params, param: payload}
                injected_url = urlunparse(parsed._replace(query=urlencode(injected)))

                response = safe_get(session, injected_url, allow_redirects=True)

                if _is_open_redirect(response, payload):
                    finding = RedirectFinding(
                        url=url,
                        parameter=param,
                        payload=payload,
                        destination=response.url if response else "",
                    )
                    findings.append(finding)
                    print_finding("MEDIUM", "OpenRedirect", f"Open Redirect at {url} — param: '{param}'")
                    break

    if not findings:
        print_finding("INFO", "OpenRedirect", "No open redirect vulnerabilities detected")

    return findings
