from dataclasses import dataclass
from urllib.parse import urljoin

from scanner.utils.http_client import build_session, safe_get
from scanner.utils.logger import get_logger, print_finding

logger = get_logger()

SENSITIVE_PATHS = [
    # Source control
    ("/.git/config", "CRITICAL", "Git repository exposed — source code may be leaking"),
    ("/.git/HEAD", "CRITICAL", "Git HEAD file exposed"),
    ("/.svn/entries", "HIGH", "SVN repository metadata exposed"),
    # Env / config files
    ("/.env", "CRITICAL", "Environment file exposed — may contain secrets, API keys, DB credentials"),
    ("/.env.local", "CRITICAL", "Local environment file exposed"),
    ("/.env.production", "CRITICAL", "Production environment file exposed"),
    ("/config.php", "HIGH", "PHP config file exposed — may contain DB credentials"),
    ("/config.yaml", "HIGH", "YAML config file exposed"),
    ("/config.json", "HIGH", "JSON config file exposed"),
    ("/settings.py", "HIGH", "Django settings file exposed"),
    # Backup files
    ("/backup.zip", "HIGH", "Backup archive exposed"),
    ("/backup.sql", "CRITICAL", "SQL database backup exposed"),
    ("/db.sql", "CRITICAL", "SQL dump file exposed"),
    ("/dump.sql", "CRITICAL", "SQL dump file exposed"),
    ("/website.zip", "HIGH", "Website archive exposed"),
    # Admin / sensitive pages
    ("/admin", "MEDIUM", "Admin panel accessible"),
    ("/phpmyadmin", "HIGH", "phpMyAdmin accessible — database management UI exposed"),
    ("/wp-admin", "MEDIUM", "WordPress admin panel accessible"),
    ("/administrator", "MEDIUM", "Administrator panel accessible"),
    # Log files
    ("/error.log", "HIGH", "Error log file exposed — may leak stack traces and paths"),
    ("/access.log", "MEDIUM", "Access log file exposed"),
    ("/debug.log", "HIGH", "Debug log exposed"),
    # Other sensitive
    ("/robots.txt", "INFO", "robots.txt found — may reveal hidden paths"),
    ("/sitemap.xml", "INFO", "Sitemap found — enumerates all URLs"),
    ("/.well-known/security.txt", "INFO", "security.txt found — good practice"),
    ("/server-status", "HIGH", "Apache server-status page exposed — reveals active connections"),
    ("/server-info", "HIGH", "Apache server-info exposed — reveals configuration"),
    ("/phpinfo.php", "HIGH", "phpinfo() page exposed — reveals full PHP configuration"),
    ("/info.php", "HIGH", "PHP info page exposed"),
    ("/test.php", "MEDIUM", "Test PHP file found"),
    ("/.DS_Store", "LOW", "macOS .DS_Store file exposed — reveals directory structure"),
    ("/package.json", "LOW", "package.json exposed — reveals dependencies"),
    ("/composer.json", "LOW", "composer.json exposed — reveals PHP dependencies"),
    ("/Dockerfile", "MEDIUM", "Dockerfile exposed — reveals infrastructure setup"),
    ("/docker-compose.yml", "MEDIUM", "docker-compose.yml exposed — reveals service configuration"),
]


@dataclass
class SensitiveFileFinding:
    url: str
    path: str
    severity: str
    description: str
    status_code: int
    content_length: int = 0


def check_sensitive_files(base_url: str) -> list[SensitiveFileFinding]:
    logger.info(f"[SensitiveFiles] Probing for exposed sensitive files on {base_url}")
    session = build_session()
    findings = []

    for path, severity, description in SENSITIVE_PATHS:
        url = urljoin(base_url, path)
        response = safe_get(session, url, allow_redirects=False)

        if not response:
            continue

        # 200 = exposed, 403 = exists but forbidden (still a finding), 401 = auth required
        if response.status_code in (200, 403, 401):
            content_length = len(response.content)

            # For 200s, skip if content is tiny (probably a custom 404)
            if response.status_code == 200 and content_length < 10:
                continue

            finding = SensitiveFileFinding(
                url=url,
                path=path,
                severity=severity,
                description=description,
                status_code=response.status_code,
                content_length=content_length,
            )
            findings.append(finding)
            status_label = f"HTTP {response.status_code}"
            print_finding(severity, "SensitiveFiles", f"[{status_label}] {path} — {description}")

    if not findings:
        print_finding("INFO", "SensitiveFiles", "No sensitive files detected")

    return findings
