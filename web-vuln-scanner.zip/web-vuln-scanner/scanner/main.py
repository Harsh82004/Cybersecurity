#!/usr/bin/env python3
"""
WebVulnScanner - Web Application Vulnerability Scanner
For authorized security testing only.
"""

import argparse
import sys
import os
from datetime import datetime
from dataclasses import asdict

from scanner.core.crawler import Crawler
from scanner.core.reporter import generate_json_report, generate_html_report
from scanner.modules.headers import check_headers
from scanner.modules.sqli import check_sqli
from scanner.modules.xss import check_xss
from scanner.modules.open_redirect import check_open_redirect
from scanner.modules.sensitive_files import check_sensitive_files
from scanner.modules.ssl_checker import check_ssl
from scanner.utils.logger import get_logger, print_banner, colorize, Color

logger = get_logger()

MODULES_ALL = ["headers", "ssl", "sensitive_files", "sqli", "xss", "open_redirect"]


def flatten_findings(findings_map: dict) -> list[dict]:
    """Flatten all module findings into a single list for reporting."""
    flat = []

    for module_name, findings in findings_map.items():
        if not findings:
            continue
        if not isinstance(findings, list):
            findings = [findings]

        for f in findings:
            d = asdict(f) if hasattr(f, "__dataclass_fields__") else vars(f)
            d["module"] = module_name
            flat.append(d)

    return flat


def parse_args():
    parser = argparse.ArgumentParser(
        prog="webvulnscan",
        description="Web Application Vulnerability Scanner — for authorized testing only",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m scanner.main https://example.com
  python -m scanner.main https://example.com --modules headers ssl sensitive_files
  python -m scanner.main https://example.com --depth 3 --output reports/my_scan
  python -m scanner.main https://example.com --no-crawl
        """,
    )
    parser.add_argument("target", help="Target URL to scan (e.g. https://example.com)")
    parser.add_argument(
        "--modules",
        nargs="+",
        choices=MODULES_ALL,
        default=MODULES_ALL,
        help="Modules to run (default: all)",
    )
    parser.add_argument("--depth", type=int, default=2, help="Crawl depth (default: 2)")
    parser.add_argument("--max-urls", type=int, default=50, help="Max URLs to crawl (default: 50)")
    parser.add_argument("--timeout", type=int, default=10, help="Request timeout in seconds (default: 10)")
    parser.add_argument("--no-crawl", action="store_true", help="Skip crawling — scan only the target URL")
    parser.add_argument("--output", default="reports/scan", help="Output file prefix (default: reports/scan)")
    parser.add_argument("--no-html", action="store_true", help="Skip HTML report generation")
    parser.add_argument("--no-json", action="store_true", help="Skip JSON report generation")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    return parser.parse_args()


def confirm_authorization(target: str) -> bool:
    print(colorize("\n⚠️  IMPORTANT LEGAL NOTICE", Color.RED))
    print("─" * 60)
    print("This tool is designed for authorized security testing ONLY.")
    print("Scanning systems without explicit permission is ILLEGAL.")
    print(f"\nTarget: {colorize(target, Color.YELLOW)}")
    answer = input("\nDo you have explicit permission to test this target? [yes/NO]: ").strip().lower()
    return answer in ("yes", "y")


def main():
    args = parse_args()
    print_banner()

    # Authorization check
    if not confirm_authorization(args.target):
        print(colorize("\n✋ Scan aborted. Only test systems you own or have written permission to test.\n", Color.RED))
        sys.exit(1)

    target = args.target.rstrip("/")
    scan_start = datetime.now()
    print(f"\n{colorize('▶ Scan started:', Color.BOLD)} {scan_start.strftime('%Y-%m-%d %H:%M:%S')}\n")

    findings_map = {}

    # ── Crawl ──────────────────────────────────────────────
    if not args.no_crawl:
        print(colorize("\n[1/6] Crawling target...", Color.CYAN))
        crawler = Crawler(target, max_depth=args.depth, max_urls=args.max_urls, timeout=args.timeout)
        crawl_result = crawler.crawl()
    else:
        from scanner.core.crawler import CrawlResult
        crawl_result = CrawlResult(base_url=target, urls={target})

    # ── Modules ────────────────────────────────────────────
    step = 2

    if "headers" in args.modules:
        print(colorize(f"\n[{step}/6] Checking Security Headers...", Color.CYAN))
        findings_map["headers"] = check_headers(target)
        step += 1

    if "ssl" in args.modules:
        print(colorize(f"\n[{step}/6] Checking SSL/TLS...", Color.CYAN))
        ssl_result = check_ssl(target)
        findings_map["ssl"] = ssl_result.findings
        step += 1

    if "sensitive_files" in args.modules:
        print(colorize(f"\n[{step}/6] Probing Sensitive Files...", Color.CYAN))
        findings_map["sensitive_files"] = check_sensitive_files(target)
        step += 1

    if "sqli" in args.modules:
        print(colorize(f"\n[{step}/6] Testing SQL Injection...", Color.CYAN))
        findings_map["sqli"] = check_sqli(crawl_result)
        step += 1

    if "xss" in args.modules:
        print(colorize(f"\n[{step}/6] Testing Cross-Site Scripting...", Color.CYAN))
        findings_map["xss"] = check_xss(crawl_result)
        step += 1

    if "open_redirect" in args.modules:
        print(colorize(f"\n[{step}/6] Testing Open Redirects...", Color.CYAN))
        findings_map["open_redirect"] = check_open_redirect(crawl_result)

    # ── Summary ────────────────────────────────────────────
    scan_end = datetime.now()
    duration = (scan_end - scan_start).total_seconds()
    flat_findings = flatten_findings(findings_map)

    from scanner.core.reporter import SEVERITY_ORDER, SEVERITY_COLORS
    counts = {s: sum(1 for f in flat_findings if f.get("severity", "").upper() == s) for s in SEVERITY_ORDER}

    print(f"\n{'─' * 60}")
    print(colorize("  SCAN SUMMARY", Color.BOLD))
    print(f"{'─' * 60}")
    print(f"  Target      : {target}")
    print(f"  Duration    : {duration:.1f}s")
    print(f"  URLs crawled: {len(crawl_result.urls)}")
    print(f"  Forms found : {len(crawl_result.forms)}")
    print(f"  Total findings: {len(flat_findings)}")
    print()
    for sev, count in counts.items():
        color = {
            "CRITICAL": Color.RED, "HIGH": Color.RED, "MEDIUM": Color.YELLOW,
            "LOW": Color.BLUE, "INFO": Color.GREEN
        }[sev]
        bar = "█" * count if count else "·"
        print(f"  {colorize(f'{sev:>8}', color)} : {count:>3}  {colorize(bar, color)}")
    print(f"{'─' * 60}\n")

    # ── Reports ────────────────────────────────────────────
    scan_data = {
        "target": target,
        "scan_time": scan_start.strftime("%Y-%m-%d %H:%M:%S"),
        "duration_seconds": round(duration, 2),
        "urls_crawled": list(crawl_result.urls),
        "all_findings_flat": flat_findings,
        "findings_by_module": {k: [asdict(f) if hasattr(f, "__dataclass_fields__") else vars(f) for f in v] for k, v in findings_map.items() if isinstance(v, list)},
    }

    os.makedirs("reports", exist_ok=True)
    timestamp = scan_start.strftime("%Y%m%d_%H%M%S")

    if not args.no_json:
        json_path = f"{args.output}_{timestamp}.json"
        generate_json_report(scan_data, json_path)
        print(f"  📄 JSON report : {json_path}")

    if not args.no_html:
        html_path = f"{args.output}_{timestamp}.html"
        generate_html_report(scan_data, html_path)
        print(f"  🌐 HTML report : {html_path}")

    print()


if __name__ == "__main__":
    main()
