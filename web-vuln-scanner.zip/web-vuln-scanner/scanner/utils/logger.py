import logging
import sys
from enum import Enum


class Color(str, Enum):
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    RESET = "\033[0m"


def colorize(text: str, color: Color) -> str:
    return f"{color.value}{text}{Color.RESET.value}"


def get_logger(name: str = "scanner") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def print_banner():
    banner = f"""
{Color.CYAN.value}{Color.BOLD.value}
 ██╗    ██╗███████╗██████╗    ██╗   ██╗██╗   ██╗██╗     ███╗   ██╗    ███████╗ ██████╗ █████╗ ███╗   ██╗
 ██║    ██║██╔════╝██╔══██╗   ██║   ██║██║   ██║██║     ████╗  ██║    ██╔════╝██╔════╝██╔══██╗████╗  ██║
 ██║ █╗ ██║█████╗  ██████╔╝   ██║   ██║██║   ██║██║     ██╔██╗ ██║    ███████╗██║     ███████║██╔██╗ ██║
 ██║███╗██║██╔══╝  ██╔══██╗   ╚██╗ ██╔╝██║   ██║██║     ██║╚██╗██║    ╚════██║██║     ██╔══██║██║╚██╗██║
 ╚███╔███╔╝███████╗██████╔╝    ╚████╔╝ ╚██████╔╝███████╗██║ ╚████║    ███████║╚██████╗██║  ██║██║ ╚████║
  ╚══╝╚══╝ ╚══════╝╚═════╝      ╚═══╝   ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝
{Color.RESET.value}
  {colorize('Web Application Vulnerability Scanner', Color.BOLD)}  |  {colorize('v1.0.0', Color.YELLOW)}  |  {colorize('For authorized testing only', Color.RED)}
  {'─' * 80}
"""
    print(banner)


def print_finding(severity: str, module: str, message: str):
    severity_colors = {
        "CRITICAL": Color.RED,
        "HIGH": Color.RED,
        "MEDIUM": Color.YELLOW,
        "LOW": Color.BLUE,
        "INFO": Color.GREEN,
    }
    color = severity_colors.get(severity.upper(), Color.RESET)
    label = colorize(f"[{severity.upper():^8}]", color)
    mod = colorize(f"[{module}]", Color.CYAN)
    print(f"  {label} {mod} {message}")
