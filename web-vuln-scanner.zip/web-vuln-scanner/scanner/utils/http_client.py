import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_HEADERS = {
    "User-Agent": "WebVulnScanner/1.0 (Security Research Tool)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
}


def build_session(timeout: int = 10, retries: int = 2, verify_ssl: bool = False) -> requests.Session:
    session = requests.Session()
    session.headers.update(DEFAULT_HEADERS)
    session.verify = verify_ssl

    retry = Retry(
        total=retries,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def safe_get(session: requests.Session, url: str, timeout: int = 10, **kwargs) -> requests.Response | None:
    try:
        return session.get(url, timeout=timeout, **kwargs)
    except requests.exceptions.RequestException:
        return None


def safe_post(session: requests.Session, url: str, data: dict, timeout: int = 10, **kwargs) -> requests.Response | None:
    try:
        return session.post(url, data=data, timeout=timeout, **kwargs)
    except requests.exceptions.RequestException:
        return None
