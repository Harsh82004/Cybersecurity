# 🔍 WebVulnScanner

> A modular, extensible Python-based web application vulnerability scanner for authorized security assessments.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?style=flat-square&logo=python)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)
![CI](https://img.shields.io/github/actions/workflow/status/yourusername/web-vuln-scanner/ci.yml?style=flat-square&label=CI)

---

## ⚠️ Legal Disclaimer

> **This tool is intended for authorized security testing ONLY.**
> Scanning or testing systems without explicit written permission is illegal and unethical.
> The author is not responsible for any misuse of this tool.

---

## Features

| Module | What It Detects |
|---|---|
| **Security Headers** | Missing CSP, HSTS, X-Frame-Options, Referrer-Policy, etc. |
| **SSL/TLS** | Expired certs, deprecated protocols (TLS 1.0/1.1), weak ciphers |
| **SQL Injection** | Error-based SQLi in URL params and HTML forms |
| **XSS** | Reflected XSS in URL params and HTML forms |
| **Open Redirect** | Unvalidated redirect parameters |
| **Sensitive Files** | Exposed `.env`, `.git`, `phpinfo`, backups, admin panels |

- 🕷️ **Built-in crawler** — auto-discovers URLs and forms up to configurable depth
- 📄 **Dual reports** — clean HTML dashboard + machine-readable JSON
- 🧩 **Modular design** — run any subset of checks independently
- ✅ **CI-ready** — GitHub Actions workflow with Bandit SAST included

---

## Installation

```bash
git clone https://github.com/yourusername/web-vuln-scanner.git
cd web-vuln-scanner
pip install -r requirements.txt
```

Or install as a package:

```bash
pip install -e .
```

---

## Usage

### Basic scan (all modules)
```bash
python -m scanner.main https://example.com
```

### Run specific modules only
```bash
python -m scanner.main https://example.com --modules headers ssl sensitive_files
```

### Deeper crawl
```bash
python -m scanner.main https://example.com --depth 3 --max-urls 100
```

### Skip crawling (scan only the root URL)
```bash
python -m scanner.main https://example.com --no-crawl
```

### Custom output path
```bash
python -m scanner.main https://example.com --output reports/my_target
```

### All options
```
usage: webvulnscan [-h] [--modules ...] [--depth N] [--max-urls N]
                   [--timeout N] [--no-crawl] [--output PATH]
                   [--no-html] [--no-json] [-v]
                   target

positional arguments:
  target              Target URL (e.g. https://example.com)

optional arguments:
  --modules           Modules to run: headers ssl sensitive_files sqli xss open_redirect
  --depth N           Crawl depth (default: 2)
  --max-urls N        Max URLs to crawl (default: 50)
  --timeout N         Request timeout in seconds (default: 10)
  --no-crawl          Skip crawling — scan root URL only
  --output PATH       Output file prefix (default: reports/scan)
  --no-html           Skip HTML report
  --no-json           Skip JSON report
  -v, --verbose       Verbose output
```

---

## Output

After a scan, two report files are saved to `reports/`:

- `scan_YYYYMMDD_HHMMSS.html` — visual dashboard
- `scan_YYYYMMDD_HHMMSS.json` — structured data for automation/integration

Example HTML report:

```
┌─────────────────────────────────────────────────────────┐
│  🔍 WebVulnScan Report — https://example.com            │
│  Scan Time: 2024-01-15 14:32:01  |  Duration: 18.4s     │
├────────────┬────────────┬────────────┬────────────┬──── │
│ CRITICAL:0 │   HIGH: 3  │ MEDIUM: 2  │   LOW: 4   │ ... │
└────────────┴────────────┴────────────┴────────────┴──── │
```

---

## Project Structure

```
web-vuln-scanner/
├── scanner/
│   ├── core/
│   │   ├── crawler.py          # Web crawler — discovers URLs and forms
│   │   └── reporter.py         # HTML + JSON report generation
│   ├── modules/
│   │   ├── headers.py          # Security headers checker
│   │   ├── sqli.py             # SQL injection scanner
│   │   ├── xss.py              # XSS scanner
│   │   ├── open_redirect.py    # Open redirect scanner
│   │   ├── sensitive_files.py  # Sensitive file exposure prober
│   │   └── ssl_checker.py      # SSL/TLS configuration checker
│   ├── utils/
│   │   ├── http_client.py      # Shared HTTP session builder
│   │   └── logger.py           # Colored console output
│   └── main.py                 # CLI entry point
├── tests/
│   ├── test_headers.py
│   ├── test_sqli.py
│   └── test_xss.py
├── reports/                    # Scan output (gitignored)
├── .github/workflows/ci.yml    # GitHub Actions CI
├── requirements.txt
├── setup.py
└── README.md
```

---

## Running Tests

```bash
pip install pytest
python -m pytest tests/ -v
```

---

## Extending the Scanner

Add a new module in 3 steps:

1. Create `scanner/modules/your_module.py` with a `check_*` function returning a list of `@dataclass` findings
2. Import and call it in `scanner/main.py`
3. Add test coverage in `tests/test_your_module.py`

Example skeleton:

```python
# scanner/modules/csrf.py
from dataclasses import dataclass
from scanner.core.crawler import CrawlResult

@dataclass
class CSRFFinding:
    url: str
    severity: str = "MEDIUM"
    description: str = "Form missing CSRF token"

def check_csrf(crawl_result: CrawlResult) -> list[CSRFFinding]:
    findings = []
    for form in crawl_result.forms:
        token_fields = [f for f in form.fields if "csrf" in f.name.lower() or "token" in f.name.lower()]
        if not token_fields:
            findings.append(CSRFFinding(url=form.action))
    return findings
```

---

## Roadmap

- [ ] CSRF token detection
- [ ] Directory traversal / path traversal checks
- [ ] SSRF detection
- [ ] Cookie security flags (HttpOnly, Secure, SameSite)
- [ ] Rate limiting / brute-force protection detection
- [ ] Subdomain enumeration
- [ ] API endpoint fuzzing

---

## License

MIT License — see [LICENSE](LICENSE) for details.
